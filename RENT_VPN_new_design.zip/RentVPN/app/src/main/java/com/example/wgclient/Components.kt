package com.example.wgclient

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp

// ---------- Палитра (чёрный фон + фиолетовый акцент) ----------
val Bg = Color(0xFF000000)
val Accent = Color(0xFF8B5CF6)
val AccentDeep = Color(0xFF5B21B6)
val AccentLight = Color(0xFFA78BFA)
val Surface1 = Color(0xFF111114)
val Surface2 = Color(0xFF1C1C21)
val LineC = Color(0xFF232329)
val Muted = Color(0xFF8E8E99)
val Good = Color(0xFF3DDC5A)
val Warn = Color(0xFFFFC857)
val Bad = Color(0xFFFF5C6C)

// ---------- Карта мира (схематичная, как фон на главной) ----------
private val continents: List<List<Pair<Float, Float>>> = listOf(
    // Северная Америка
    listOf(40f to 345f, 120f to 320f, 230f to 315f, 300f to 330f, 340f to 350f, 300f to 380f, 270f to 430f,
        250f to 470f, 215f to 455f, 190f to 470f, 150f to 430f, 110f to 420f, 80f to 390f),
    // Гренландия
    listOf(300f to 290f, 370f to 280f, 375f to 310f, 340f to 330f),
    // Южная Америка
    listOf(205f to 520f, 250f to 515f, 310f to 555f, 300f to 610f, 260f to 680f, 235f to 690f, 225f to 620f, 195f to 560f),
    // Европа
    listOf(400f to 380f, 440f to 350f, 500f to 360f, 490f to 400f, 440f to 420f, 410f to 410f),
    // Африка
    listOf(400f to 430f, 480f to 425f, 540f to 470f, 520f to 540f, 490f to 610f, 450f to 600f, 430f to 520f, 395f to 470f),
    // Азия
    listOf(500f to 350f, 600f to 320f, 720f to 330f, 820f to 350f, 800f to 410f, 740f to 440f, 690f to 520f,
        650f to 470f, 600f to 460f, 560f to 430f, 510f to 400f),
    // Австралия
    listOf(730f to 590f, 800f to 590f, 830f to 640f, 790f to 680f, 740f to 660f),
)

// Светящиеся точки серверов (x, y в тех же координатах)
private val mapDots: List<Pair<Float, Float>> = listOf(
    150f to 407f, 218f to 548f, 422f to 398f, 454f to 408f, 540f to 465f,
    706f to 406f, 752f to 457f, 714f to 477f, 685f to 566f, 785f to 628f,
)

private const val MAP_W = 852f
private const val MAP_Y0 = 260f
private const val MAP_H = 440f

/** Соотношение сторон карты (ширина / высота). */
const val WORLD_MAP_ASPECT = MAP_W / MAP_H

@Composable
fun WorldMap(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val k = size.width / MAP_W
        for (poly in continents) {
            val p = Path()
            poly.forEachIndexed { i, (x, y) ->
                val px = x * k; val py = (y - MAP_Y0) * k
                if (i == 0) p.moveTo(px, py) else p.lineTo(px, py)
            }
            p.close()
            drawPath(p, Color(0xFF17171A))
            drawPath(p, Color(0xFF1D1D21), style = Stroke(1.5f * k, join = StrokeJoin.Round))
        }
        for ((x, y) in mapDots) {
            val c = Offset(x * k, (y - MAP_Y0) * k)
            drawCircle(Accent.copy(alpha = 0.18f), radius = 9f * k, center = c)
            drawCircle(Accent, radius = 4f * k, center = c)
        }
    }
}

// ---------- Кнопка питания (кольцо) ----------
@Composable
fun PowerRing(state: VpnState, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "power")
    val spin = transition.animateFloat(
        0f, 360f, infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart), label = "spin"
    )
    Box(
        modifier
            .size(148.dp)
            .clip(CircleShape)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(148.dp)) {
            val c = center
            val r = size.minDimension / 2f
            // внешнее тонкое кольцо
            drawCircle(Color(0xFF2A2A30), radius = r * 0.995f, center = c, style = Stroke(1.5.dp.toPx()))
            drawCircle(Color(0xFF050506), radius = r * 0.985f, center = c)
            // свечение
            val glow = if (state == VpnState.DISCONNECTED) 0.22f else 0.4f
            drawCircle(
                Brush.radialGradient(
                    listOf(Accent.copy(alpha = glow), Color.Transparent),
                    center = c, radius = r * 0.9f
                ),
                radius = r * 0.9f, center = c
            )
            val ringR = r * 0.78f
            val w = r * 0.085f
            when (state) {
                VpnState.CONNECTED -> {
                    drawCircle(
                        Brush.radialGradient(listOf(AccentLight, AccentDeep), center = c, radius = ringR),
                        radius = ringR, center = c
                    )
                }
                VpnState.CONNECTING -> {
                    drawCircle(Accent.copy(alpha = 0.25f), radius = ringR, center = c, style = Stroke(w))
                    rotate(spin.value, c) {
                        drawArc(
                            AccentLight, startAngle = 0f, sweepAngle = 110f, useCenter = false,
                            topLeft = Offset(c.x - ringR, c.y - ringR), size = Size(ringR * 2, ringR * 2),
                            style = Stroke(width = w, cap = StrokeCap.Round)
                        )
                    }
                }
                VpnState.DISCONNECTED -> {
                    drawCircle(
                        Brush.sweepGradient(listOf(AccentLight, Accent, AccentDeep, Accent, AccentLight), center = c),
                        radius = ringR, center = c, style = Stroke(w)
                    )
                }
            }
            // тёмная сердцевина (кроме подключённого состояния — там залита вся)
            if (state != VpnState.CONNECTED) {
                drawCircle(Color(0xFF050506), radius = ringR - w / 2f, center = c)
            }
        }
        PowerIcon(Color.White, Modifier.size(38.dp))
    }
}

@Composable
fun PowerIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val stroke = Stroke(width = w * 0.085f, cap = StrokeCap.Round)
        drawArc(
            color, startAngle = -60f, sweepAngle = 300f, useCenter = false,
            topLeft = Offset(w * 0.17f, w * 0.2f), size = Size(w * 0.66f, w * 0.66f), style = stroke
        )
        drawLine(color, Offset(w * 0.5f, w * 0.08f), Offset(w * 0.5f, w * 0.46f), strokeWidth = stroke.width, cap = StrokeCap.Round)
    }
}

// ---------- Иконки ----------
private fun DrawScope.shieldPath(w: Float): Path = Path().apply {
    moveTo(w * .5f, w * .04f)
    lineTo(w * .92f, w * .18f)
    lineTo(w * .92f, w * .5f)
    cubicTo(w * .92f, w * .76f, w * .72f, w * .91f, w * .5f, w * .98f)
    cubicTo(w * .28f, w * .91f, w * .08f, w * .76f, w * .08f, w * .5f)
    lineTo(w * .08f, w * .18f)
    close()
}

/** Логотип: щит с замком. */
@Composable
fun LogoShield(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        drawPath(shieldPath(w), Accent, style = Stroke(w * .06f, join = StrokeJoin.Round))
        // замок
        drawArc(AccentLight, 180f, 180f, false, Offset(w * .39f, w * .27f), Size(w * .22f, w * .26f), style = Stroke(w * .05f))
        drawRoundRect(
            Brush.verticalGradient(listOf(AccentLight, Accent)),
            Offset(w * .32f, w * .42f), Size(w * .36f, w * .27f),
            androidx.compose.ui.geometry.CornerRadius(w * .05f)
        )
        drawCircle(Color(0xFF1A1030), w * .035f, Offset(w * .5f, w * .53f))
    }
}

/** Щит с галочкой (строка «Ваши данные в безопасности»). */
@Composable
fun ShieldCheckIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        drawPath(shieldPath(w), color, style = Stroke(w * .07f, join = StrokeJoin.Round))
        val tick = Path().apply { moveTo(w * .32f, w * .5f); lineTo(w * .45f, w * .63f); lineTo(w * .69f, w * .37f) }
        drawPath(tick, color, style = Stroke(w * .07f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun GearIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val st = Stroke(w * .08f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        drawCircle(color, w * .15f, center, style = st)
        drawCircle(color, w * .31f, center, style = Stroke(w * .08f))
        for (i in 0 until 8) {
            rotate(i * 45f, center) {
                drawLine(color, Offset(w * .5f, w * .08f), Offset(w * .5f, w * .2f), w * .11f, StrokeCap.Round)
            }
        }
    }
}

@Composable
fun PlayIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width; val h = size.height
        val p = Path().apply { moveTo(w * .15f, h * .08f); lineTo(w * .92f, h * .5f); lineTo(w * .15f, h * .92f); close() }
        drawPath(p, color)
    }
}

@Composable
fun StopIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        drawRoundRect(color, Offset(size.width * .15f, size.height * .15f), Size(size.width * .7f, size.height * .7f),
            androidx.compose.ui.geometry.CornerRadius(size.width * .12f))
    }
}

@Composable
fun BoltIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width; val h = size.height
        val p = Path().apply {
            moveTo(w * .62f, h * .02f); lineTo(w * .2f, h * .56f); lineTo(w * .48f, h * .56f)
            lineTo(w * .36f, h * .98f); lineTo(w * .82f, h * .4f); lineTo(w * .52f, h * .4f); close()
        }
        drawPath(p, color)
    }
}

/** Стрелка вниз/вверх с чертой (скорость). */
@Composable
fun SpeedArrowIcon(down: Boolean, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val st = Stroke(w * .08f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        if (down) {
            drawLine(color, Offset(w * .5f, w * .08f), Offset(w * .5f, w * .66f), st.width, StrokeCap.Round)
            val p = Path().apply { moveTo(w * .26f, w * .44f); lineTo(w * .5f, w * .68f); lineTo(w * .74f, w * .44f) }
            drawPath(p, color, style = st)
            drawLine(color, Offset(w * .14f, w * .92f), Offset(w * .86f, w * .92f), st.width, StrokeCap.Round)
        } else {
            drawLine(color, Offset(w * .5f, w * .92f), Offset(w * .5f, w * .34f), st.width, StrokeCap.Round)
            val p = Path().apply { moveTo(w * .26f, w * .56f); lineTo(w * .5f, w * .32f); lineTo(w * .74f, w * .56f) }
            drawPath(p, color, style = st)
            drawLine(color, Offset(w * .14f, w * .08f), Offset(w * .86f, w * .08f), st.width, StrokeCap.Round)
        }
    }
}

/** Шеврон: 0 — вниз, 1 — вправо. */
@Composable
fun ChevronIcon(dir: Int, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val p = Path().apply {
            if (dir == 0) { moveTo(w * .15f, w * .32f); lineTo(w * .5f, w * .68f); lineTo(w * .85f, w * .32f) }
            else { moveTo(w * .32f, w * .15f); lineTo(w * .68f, w * .5f); lineTo(w * .32f, w * .85f) }
        }
        drawPath(p, color, style = Stroke(w * .09f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Иконки нижнего меню: 0 — главная, 1 — статистика, 2 — настройки. */
@Composable
fun NavIcon(kind: Int, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        when (kind) {
            0 -> { // дом (залитый)
                val p = Path().apply {
                    moveTo(w * .5f, w * .08f); lineTo(w * .92f, w * .46f); lineTo(w * .82f, w * .46f)
                    lineTo(w * .82f, w * .9f); lineTo(w * .6f, w * .9f); lineTo(w * .6f, w * .62f)
                    lineTo(w * .4f, w * .62f); lineTo(w * .4f, w * .9f); lineTo(w * .18f, w * .9f)
                    lineTo(w * .18f, w * .46f); lineTo(w * .08f, w * .46f); close()
                }
                drawPath(p, color)
            }
            1 -> { // столбики
                val bw = w * .16f
                val r = androidx.compose.ui.geometry.CornerRadius(bw / 2)
                drawRoundRect(color, Offset(w * .12f, w * .55f), Size(bw, w * .35f), r)
                drawRoundRect(color, Offset(w * .42f, w * .3f), Size(bw, w * .6f), r)
                drawRoundRect(color, Offset(w * .72f, w * .1f), Size(bw, w * .8f), r)
            }
            else -> { // сетка 2x2
                val s = w * .34f
                val r = androidx.compose.ui.geometry.CornerRadius(w * .08f)
                drawRoundRect(color, Offset(w * .1f, w * .1f), Size(s, s), r)
                drawRoundRect(color, Offset(w * .56f, w * .1f), Size(s, s), r)
                drawRoundRect(color, Offset(w * .1f, w * .56f), Size(s, s), r)
                drawRoundRect(color, Offset(w * .56f, w * .56f), Size(s, s), r)
            }
        }
    }
}

/** Вертикальные столбики качества связи + значение. */
@Composable
fun PingBars(ping: Int?, modifier: Modifier = Modifier) {
    val level = when {
        ping == null -> 0
        ping < 120 -> 4
        ping < 250 -> 3
        ping < 450 -> 2
        else -> 1
    }
    val col = when (level) { 4, 3 -> Good; 2 -> Warn; 1 -> Bad; else -> Muted }
    Canvas(modifier) {
        val bw = size.width / 7f
        for (i in 0 until 4) {
            val h = size.height * (0.4f + 0.2f * i)
            drawRoundRect(
                if (i < level) col else Color(0xFF3A3A3A),
                Offset(i * bw * 1.7f, size.height - h), Size(bw, h),
                androidx.compose.ui.geometry.CornerRadius(bw / 2)
            )
        }
    }
}

/** Заливка-«спарклайн» для экрана скорости. */
fun DrawScope.sparkline(values: List<Long>, color: Color) {
    if (values.size < 2) return
    val max = (values.maxOrNull() ?: 1L).coerceAtLeast(1L).toFloat()
    val step = size.width / (values.size - 1)
    val line = Path()
    val fill = Path()
    values.forEachIndexed { i, v ->
        val x = i * step
        val y = size.height - (v / max) * size.height * 0.9f - 2f
        if (i == 0) { line.moveTo(x, y); fill.moveTo(x, size.height); fill.lineTo(x, y) } else { line.lineTo(x, y); fill.lineTo(x, y) }
    }
    fill.lineTo(size.width, size.height); fill.close()
    drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = .35f), Color.Transparent)))
    drawPath(line, color, style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
}
